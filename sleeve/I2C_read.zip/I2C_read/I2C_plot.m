% MATLAB code plots data from two IMU motion sensors using a multiplexer, and two EMG sensors
% Reads data from an Arduino on USB serial port. 
% IMU Accelerometer has three outputs (x, y, z)
% EMG sensor has a single output (EMG analog voltage)

% IMU (GY-85) components
%  Accelerometer =  ADXL345
%  Gyroscope =  ITG3205
%  Magnetometer =  HMC5883L

clear;clc;clearvars;

%Plot
figure(1);
ax(1) = subplot(2,2,1);
plotGraph(1) = plot(0,0);

ax(2) = subplot(2,2,2);
plotGraph(2) = plot(0,0);

ax(3) = subplot(2,2,3);
plotGraph(3) = plot(0,0);

ax(4) = subplot(2,2,4);
plotGraph(4) = plot(0,0);

% Acceleration range, for graphing
minInputA = -1;
maxInputA = 1;

% EMG Analog signal range, for graphing
minInputE = 0;
maxInputE = 1023;

% Rotational accelertion range, for graphing
minInputG = -pi;
maxInputG = pi;

% Heading range, for graphing
minInputH = -pi;
maxInputH = pi;

xWidth = 10;      % width of sliding window

numberOfSensors = 2; % if using a multiplexor, if not, set to 1
numberOfExpectedInputs = 12; % per sensor (per serial line)

% Initial starting conditions
Xa = 0;
Ya = 0;
Za = 0;

Xg = 0;
Yg = 0;
Zg = 0;

Xm =0;
Ym =0;
Zm =0;

EMG1 = 0;
EMG2 =0;

time = 0;
count = 0;

% Open port
disp('Opening connection ...')
s = serial('/dev/ttyUSB0')
set(s, 'DataBits', 8);
set(s, 'StopBits', 1);
set(s, 'BaudRate', 9600);
set(s, 'Parity', 'none');
fopen(s);

% Check to see if all components have initalised
disp(fgets(s)); % display initalision
pause(1);
disp(fgets(s)); % Connected!

tic

try
    
    flag=1; 
    count=1;
  
  while true
      expectedSensor=1;  
        while expectedSensor<=numberOfSensors
            
            raw_dat = fscanf(s);
            formatted=[];
            
            for i=1:numberOfExpectedInputs
                
                [TK raw_dat]=strtok(raw_dat,',');
                try
                    
                    formatted(i)=str2num(TK);
                catch
                end
            end
            dat=formatted';
            
            % If something went wrong with this reading           
            if~(~isempty(dat) && isfloat(dat) && size(dat,1)==numberOfExpectedInputs) % as data is sometimes dropped
                disp('wrong serial size')

                sensor=expectedSensor;
                ID(count,sensor) = expectedSensor;
                Xa(count,sensor)  = NaN;
                Ya(count,sensor)  = NaN;
                Za(count,sensor)  = NaN;
                Xg(count,sensor)  = NaN;
                Yg(count,sensor) = NaN;
                Zg(count,sensor)  = NaN;
                Xm(count,sensor)  = NaN;
                Ym(count,sensor) = NaN;
                Zm(count,sensor)  = NaN;                
                EMG1(count, sensor) = NaN;
                EMG2(count, sensor) = NaN;
                
                          
                flag=true;       
            elseif dat(1)~=expectedSensor
                disp('data is misaligned');
                sensor = dat(1);
                ID(count,sensor) = NaN;
                Xa(count,sensor)  = NaN;
                Ya(count,sensor)  = NaN;
                Za(count,sensor)  = NaN;
                Xg(count,sensor)  = NaN;
                Yg(count,sensor) = NaN;
                Zg(count,sensor)  = NaN;
                Xm(count,sensor)  = NaN;
                Ym(count,sensor) = NaN;
                Zm(count,sensor)  = NaN;                
                EMG1(count, sensor) = NaN;
                EMG2(count, sensor) = NaN;
                

                flag=false;
            else
                % Read raw data from serial
                % first item is the sensor ID num
                %truesensor = dat(1);
                sensor=expectedSensor;
                ID(count,sensor) = dat(1);
                Xa(count,sensor) = dat(2);
                Ya(count,sensor) = dat(3);
                Za(count,sensor) = dat(4);
                Xg(count,sensor) = dat(5);
                Yg(count,sensor) = dat(6);
                Zg(count,sensor) = dat(7);
                Xm(count,sensor) = dat(8);
                Ym(count,sensor) = dat(9);
                Zm(count,sensor) = dat(10);                
                EMG1(count, sensor) = dat(11);
                EMG2(count, sensor) = dat(12);
                  
                flag=true;
            end
                
                % Convert into usable units
                % Acceleration
                sensitivity_a=256;
                Xa_g(count,sensor) = Xa(count,sensor)/sensitivity_a;
                Ya_g(count,sensor) = Ya(count,sensor)/sensitivity_a;
                Za_g(count,sensor) = Za(count,sensor)/sensitivity_a;
                 
                % Angular acceleration
                sensitivity_g = 14.375;% This is the gain (sensitivity level, in datasheet, and set in arduino code)
                Xg_rad_s(count,sensor) = Xg(count,sensor)/sensitivity_g; 
                Yg_rad_s(count,sensor) = Yg(count,sensor)/sensitivity_g;
                Zg_rad_s(count,sensor) = Zg(count,sensor)/sensitivity_g;
       
                if flag==true
                    if expectedSensor==1
                        expectedSensor=2;
                    else
                        break;
                    end
                end

        end
        time(count) = toc; % assumes all readings (from all sensors), taken at exactly the same time
        
        % Speed up graphing
        time_subset=time(time > time(count)-xWidth);
        Xa_sub=Xa_g(time > time(count)-xWidth,:);
        Ya_sub=Ya_g(time > time(count)-xWidth,:);
        Za_sub=Za_g(time > time(count)-xWidth,:);
        
        Xg_rad_s_sub=Xg_rad_s(time > time(count)-xWidth,:);
        Yg_rad_s_sub=Yg_rad_s(time > time(count)-xWidth,:);
        Zg_rad_s_sub=Zg_rad_s(time > time(count)-xWidth,:);
        
        EMG1_sub = EMG1(time > time(count)-xWidth);
        EMG2_sub = EMG2(time > time(count)-xWidth);

        
        % Plot first Sensor with Z (red), X (blue), Y (green)
        plot(ax(1), time_subset,Za_sub(:,1),'-r', time_subset, Xa_sub(:,1), '-b', time_subset, Ya_sub(:,1),'-g', 'linewidth',2);
        axis(ax(1),[time(count)-xWidth time(count) -2 2]);
        xlabel(ax(1), 'Time (s)');
        ylabel(ax(1), 'Acceleration Sensor 1 (g)');
        
        % Plot second Sensor with Z (red), X (blue), Y (green)
        plot(ax(2), time_subset,Za_sub(:,2),'-r', time_subset, Xa_sub(:,2), '-b', time_subset, Ya_sub(:,2),'-g', 'linewidth',2);
        axis(ax(2),[time(count)-xWidth time(count) -2 2]);
        xlabel(ax(2), 'Time (s)');
        ylabel(ax(2), 'Acceleration Sensor 2 (g)');
        
        % Plot analog signal from first EMG component
        plot(ax(3), time_subset, EMG1_sub, '-g', 'linewidth', 3);
        axis(ax(3),[time(count)-xWidth time(count) 0 1023]);
        xlabel(ax(3), 'Time (s)');
        ylabel(ax(3), 'Analog 1 ');
        
        % Plot analog signal from second EMG component
        plot(ax(4), time_subset, EMG2_sub, '-g', 'linewidth', 3);
        axis(ax(4),[time(count)-xWidth time(count) -400 500]);
        xlabel(ax(4), 'Time (s)');
        ylabel(ax(4), 'Analog 2 ');
        
        drawnow;
        count = count + 1;
    end
    
catch err
    fclose(s);
    disp('crashed, closed serial')
    rethrow(err);
    
end

fclose(s);

